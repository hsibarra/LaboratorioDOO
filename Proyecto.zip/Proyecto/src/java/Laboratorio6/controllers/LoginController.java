/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio6.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Laboratorio6.models.Authentication;
import Laboratorio6.models.Md5;
import Laboratorio6.models.User;
import javax.servlet.http.HttpSession;

/**
 *
 * @author SEG-13
 */
public class LoginController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String id = request.getParameter("user");
        String pswr = request.getParameter("pswd");
        String compare = request.getParameter("opti");
        Md5 md5 = new Md5();
        String pswd = md5.getMD5(pswr);

        if (compare.equals("crear")) {
            Authentication aute = new Authentication();
            User user = new User(id, pswd);
            aute.insertar(user);
            response.sendRedirect("login.jsp");

        } else if (compare.equals("sesion")) {
            
            Authentication authentication = new Authentication();
            authentication.buscar(id, pswd);

            boolean isValidUser = Authentication.authenticate(id, pswd);

            if (isValidUser) {

                User user = new User(id, pswd);
                session.setAttribute("username", user.getUsername());
                session.setAttribute("name", user.getName());
                session.setAttribute("fullname", user.getFullName());

                response.sendRedirect("votaciones.jsp");

            } else {
                response.sendRedirect("error.jsp");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
