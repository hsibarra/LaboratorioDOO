/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio6.models;

/**
 *
 * @author Liliana y Irenia
 */
public class Versus {


    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }


    public String getTitulo() {
        return titulo;
    }


    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public String getPlatillo1() {
        return platillo1;
    }


    public void setPlatillo1(String platillo1) {
        this.platillo1 = platillo1;
    }


    public String getPlatillo2() {
        return platillo2;
    }

    public void setPlatillo2(String platillo2) {
        this.platillo2 = platillo2;
    }
    private String id;
    private String titulo;
    private String platillo1;
    private String platillo2;
    
    public Versus(){
        
    }
    
    public Versus(String id, String titulo, String platillo1, String platillo2){
        this.id = id;
        this.titulo = titulo;
        this.platillo1 = platillo1;
        this.platillo2 = platillo2;
       
    }
}
