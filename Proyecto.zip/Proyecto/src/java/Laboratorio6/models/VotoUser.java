/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio6.models;

/**
 *
 * @author Liliana y Irenia
 */
public class VotoUser {

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getIdVotacion() {
        return idVotacion;
    }

    public void setIdVotacion(String idVotacion) {
        this.idVotacion = idVotacion;
    }

    public String getIdPlatillo() {
        return idPlatillo;
    }

    public void setIdPlatillo(String idPlatillo) {
        this.idPlatillo = idPlatillo;
    }

    private String usuario;
    private String idVotacion;
    private String idPlatillo;

    public VotoUser() {

    }

    public VotoUser(String usuario, String idVotacion, String idPlatillo) {
        this.usuario = usuario;
        this.idVotacion = idVotacion;
        this.idPlatillo = idPlatillo;

    }
}
